=== lcmicro ===

A Python library for nonlinear microscopy and polarimetry.

Author: Lukas Kontenis
Copyright 2015-2020 Light Conversion
Contact: lukas.kontenis@lightcon.com, dse.ssd@gmail.com
